package com.cg.quoteapis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.quoteapis.entity.Quote;
import com.cg.quoteapis.service.QuoteService;

@RestController
@SpringBootApplication
public class QuoteapisApplication implements ErrorController, CommandLineRunner {

	@Autowired
	private QuoteService service;

	private static final String PATH = "/error";

	public static void main(String[] args) {
		SpringApplication.run(QuoteapisApplication.class, args);
	}

	@GetMapping(value = PATH)
	public String error() {
		return "Pls Enter a valid EndPoint";
	}

	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return PATH;
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		List<Quote> list = new ArrayList<Quote>(Arrays.asList(new Quote(11L, "Do Or Die", "Mahatma Gandhi"),
				new Quote(22L, "Look before You Leap", "Naveen")));

		service.saveQuotes(list);

	}

}
