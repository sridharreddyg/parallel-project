package com.cg.quoteapis.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.quoteapis.dao.QuoteRepository;
import com.cg.quoteapis.entity.Quote;

@Service
public class QuoteService {

	@Autowired
	private QuoteRepository repo;

	public Quote save(Quote quote) {
		return repo.save(quote);
	}

	public List<Quote> getQuotes() {
		return (List<Quote>) repo.findAll();
	}

	public void saveQuotes(List<Quote> list) {
		repo.saveAll(list);
	}

	public Optional<Quote> getQuoteById(Long id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	public void delete(Long id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

}
