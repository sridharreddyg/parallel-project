package com.cg.eis.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
import com.cg.eis.util.CollectionUtil;

public class AccDaoClass implements AccDaoInterface{
	CollectionUtil cu=new CollectionUtil();
	Account a=new Account();
	static Connection c;
	Statement stmt=null;
	PreparedStatement preparedStmt=null;
	public ResultSet storedAccounts() throws SQLException {
		List<Account> list=null;
		PreparedStatement ps=cu.c.prepareStatement("select *from BankAccount");
		ResultSet rs=ps.executeQuery();
		return rs;
		
	}
	public void display(Account a) throws AccountException {
		try {
		PreparedStatement preparedStmt=cu.c.prepareStatement("insert into BankAccount values(?,?,?,?,?,?,?,?)");
		preparedStmt.setInt(1, a.getAccnum());
		preparedStmt.setString(2, a.getAccname());
		preparedStmt.setLong(3, a.getMobilenum());
		preparedStmt.setLong(4, a.getAdhaarnum());
		preparedStmt.setInt(5, a.getDeposite());
		preparedStmt.setInt(6, a.getWithdraw());
		preparedStmt.setInt(7, a.getTransfer());
		preparedStmt.setInt(8, a.getWalbalance());
		preparedStmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	public Account walDetails(int a,int walbalance) throws AccountException {
		Account a1 = null;
			try {
				 preparedStmt = cu.c.prepareStatement("select*from BankAccount where accnum=?");
				 preparedStmt.setInt(1, a);
				ResultSet rs= preparedStmt.executeQuery();
				while(rs.next())
				a1=new Account(rs.getLong(3), rs.getInt(8), rs.getInt(1), rs.getLong(4), rs.getString(2), rs.getInt(5), rs.getInt(7), rs.getInt(6));
		
			} catch (SQLException e) {
				e.printStackTrace();
			}	
			return a1;
		}
		
	public int details(int a,int deposit) throws SQLException {	
		int n = 0;
		 preparedStmt = cu.c.prepareStatement("update BankAccount set walbalance=walbalance+?,deposit=deposit+? where accnum=?");
		 preparedStmt.setInt(2, deposit);
		 preparedStmt.setInt(1, deposit);
		 preparedStmt.setInt(3, a);
		 preparedStmt.executeQuery();
		 PreparedStatement preparedStmt1 = cu.c.prepareStatement("select deposit from BankAccount where accnum=?");
		 preparedStmt1.setInt(1, a);
		 ResultSet rs=preparedStmt1.executeQuery();
		 while(rs.next())
			 n=rs.getInt(1);
	return n;
	}
	public int withdrawdetails(int a, int withdraw) throws SQLException {
		int n=0;
		 preparedStmt = cu.c.prepareStatement("update BankAccount set walbalance=walbalance-?,withdraw=withdraw+? where accnum=?");		
		 preparedStmt.setInt(1, withdraw);
		 preparedStmt.setInt(2, withdraw);
		 preparedStmt.setInt(3, a);
		  preparedStmt.executeQuery();
		  PreparedStatement preparedStmt1 = cu.c.prepareStatement("select withdraw from BankAccount where accnum=?");
			 preparedStmt1.setInt(1, a);
			 ResultSet rs=preparedStmt1.executeQuery();
			 while(rs.next())
				 n=rs.getInt(1);
		 return n;
	}
		
	public int transferdetails(int a, int transfer) throws SQLException {
		int n=0;
		 preparedStmt = cu.c.prepareStatement("update BankAccount set walbalance=walbalance-?,transfer=transfer+? where accnum=?");
		 preparedStmt.setInt(1, transfer);
		 preparedStmt.setInt(2, transfer);
		 preparedStmt.setInt(3, a);
		 preparedStmt.executeQuery();
		 PreparedStatement preparedStmt1 = cu.c.prepareStatement("select transfer from BankAccount where accnum=?");
		 preparedStmt1.setInt(1, a);
		 ResultSet rs=preparedStmt1.executeQuery();
		 while(rs.next())
			 n=rs.getInt(1);
		return n;
	}
	public  PrintTransaction printtransaction(int a) throws SQLException {
		PrintTransaction pt1 = null;
			PreparedStatement preparedStmt1 = cu.c.prepareStatement("select*from BankAccount where accnum=?");
			 preparedStmt1.setInt(1, a);
			ResultSet rs= preparedStmt1.executeQuery();
			while(rs.next())
			pt1=new PrintTransaction(rs.getInt(6), rs.getInt(5), rs.getInt(7));	
		return pt1;
	}
	
}