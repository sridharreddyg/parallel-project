package com.cg.eis.entity;

public class PrintTransaction {
	public int getDeposite() {
		return deposite;
	}
	public void setDeposite(int deposite) {
		this.deposite = deposite;
	}
	public int getTransfer() {
		return transfer;
	}
	public void setTransfer(int transfer) {
		this.transfer = transfer;
	}
	@Override
	public String toString() {
		return "Transaction details is {"
				+ " Total withdrawn amount=" + withdraw +
				",Total deposited amount=" + deposite + 
				",Total transfered amount=" + transfer +
				 "}";
	}
	private int withdraw;
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	private int deposite;
	public PrintTransaction(int withdraw, int deposite, int transfer) {
		super();
		this.withdraw = withdraw;
		this.deposite = deposite;
		this.transfer = transfer;
	}
	private int transfer;

}
