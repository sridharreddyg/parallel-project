package com.cg.eis.ui;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.cg.eis.Exception.AccountException;
import com.cg.eis.dao.AccDaoClass;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
import com.cg.eis.service.AccServClass;

public class AccMain {
	static Scanner sc=null;
	public static void main(String[] args) throws  SQLException {
		String continueChoice ;
		sc=new Scanner(System.in);
		Account a=new Account();
		AccServClass asc=new AccServClass();
		AccDaoClass adc=new AccDaoClass();
		do {
			System.out.println("Welcome to XYZ Bank");
			ResultSet rs=adc.storedAccounts();
			System.out.println("************displaying the Existing records************");
			while(rs.next()) {
				
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getLong(3)+" "+rs.getLong(4)+" "+rs.getInt(5)+" "+rs.getInt(6)+" "+rs.getInt(7)+" "+rs.getInt(8));
			}
		System.out.println("1:BankAccount number\t 2:create wallet account\t 3:show balance\n"
				+ " 4:Deposit\t 5:withdraw\t6:Transfer\t7:Print Transaction");
		int choice;
		boolean choiceFlag = false;
		do {
			sc=new Scanner(System.in);
			System.out.println("enter your choice");
			try {
				 choice=sc.nextInt();
				choiceFlag = true;
		switch(choice) {
		case 1:
		int max=915009999;
		int min=915000000;
		int range=max-min+1;
		int accnumber=(int) (Math.random()*range)+min;
		System.out.println("yout bank account number is: "+accnumber);
		a.setAccnum(accnumber);
		System.out.println();
		break;
		case 2:
		if(a.getAccnum()!=0) {
			int acc;
			String name;
			boolean accFlag = false;
		System.out.println("-------creating wallet waccount---------");
		do {
			sc=new Scanner(System.in);
			System.out.println("enter the account number");
			acc=sc.nextInt();
			try {
					asc.validateAccNum(acc);
					accFlag=true;
					break;
				}catch(AccountException e) {
					accFlag = false;
					System.err.println(e.getMessage());
				}
			} while (!accFlag);
						if(acc==a.getAccnum()) {
							boolean nameFlag=false;						
							do { 
								sc = new Scanner(System.in);
								System.out.println("Enter name ");
								name = sc.nextLine();
								try {
									asc.validateName(name);
									nameFlag = true;
									a.setAccname(name);
									break;

								} catch (AccountException e) {
									nameFlag = false;
									System.err.println(e.getMessage());
								}
							} while (!nameFlag);
					
							boolean mobFlag=false;
							String num;
							do {
							System.out.println("enter the mobile number: ");
							num=sc.next();
							try {
								asc.validateMobile(num);
								mobFlag=true;
								a.setMobilenum(Long.valueOf(num));
								break;
							} catch (AccountException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
							}while (!nameFlag);
							boolean adhFlag=false;
							String adh;
							do {
								System.out.println("enter the adhaar number: ");
								 adh=sc.next();
								try {
									asc.validateAdhaar(adh);
									adhFlag=true;
									a.setAdhaarnum(Long.valueOf(adh));
									asc.display(a);
									System.out.println("yout xyz wallet account is successfully created");
									break;
								}catch (AccountException e) {
									nameFlag = false;
									System.err.println(e.getMessage());
								}
								}while (!adhFlag);
							
						}
						else {					
							System.out.println("account number is invalid");
						}
		}else
			System.out.println("first create wallet account");
			break;
		case 3:
			if(a.getAccnum()!=0) {
				
				Account c = null;
				boolean accFlag4=false;
				int accnum;
				do {
				System.out.println("ENTER THE ACCOUNT NUMBER");
				try {
					accnum=sc.nextInt();
					asc.validateAccNum(accnum);
					accFlag4=true;
				c = asc.walDetails(accnum, a.getWalbalance());
				System.out.println(c);
				break;
			} catch (AccountException e) {
				accFlag4=false;
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(c);
			}while(!accFlag4);
			}
			else
				System.out.println("first create account");
			break;
		case 4:	
			if(a.getAccnum()!=0) {
			boolean accFlag4=false;
			int accnum;
			do {
			System.out.println("ENTER THE ACCOUNT NUMBER");
			try {
				accnum=sc.nextInt();
				asc.validateAccNum(accnum);
				accFlag4=true;
				if(a.getAccnum()==accnum)
				{
				System.out.println("enter the amount you want deposit");
				int deposit=sc.nextInt();
				int s=asc.details(accnum, deposit);
				System.out.println("successfully deposited: "+deposit);
				System.out.println("your total deposited balance is: "+s);
				break;
				}else
					System.out.println("invalid account number");
			}catch(AccountException e)
			{
				accFlag4=false;
				System.err.println(e.getMessage());
			}
			}while(!accFlag4);
			}else
				System.out.println("first create  wallet account");
			break;
		case 5:
			if(a.getAccnum()!=0) {
			boolean accFlag5=false;
			int accnum1;
			do {
			System.out.println("ENTER THE ACCOUNT NUMBER");
			try {
				accnum1=sc.nextInt();
				asc.validateAccNum(accnum1);
				accFlag5=true;
				if(a.getAccnum()==accnum1) {
					System.out.println("enter amount you want withdraw");
					int withdraw=sc.nextInt();
					int b= asc.withdrawdetails(accnum1, withdraw);
					if(b!=0) {
						System.out.println("successfully withdrawn: "+withdraw);
						System.out.println("your totally withdrawn balance is: "+b);
						break;
					}
					else
						System.out.println("insufficient funds");
				}else
					System.out.println("invalid account number");
			}catch(AccountException e)
			{
				accFlag5=false;
				System.err.println(e.getMessage());
			}
			}while(!accFlag5);
			}else
				System.out.println("first you need to create account");
			break;
		case 6:
			if(a.getAccnum()!=0) {
			boolean accFlag1=false;
			int accnum2 = 0;
			do {
			System.out.println("ENTER THE ACCOUNT NUMBER");
			try {
				accnum2=sc.nextInt();
				asc.validateAccNum(accnum2);
				accFlag1=true;
				break;
			}catch(AccountException e)
			{
				accFlag1=false;
				System.err.println(e.getMessage());
			}
			}while(!accFlag1);
			if(a.getAccnum()==accnum2)					
			{
				boolean accFlag2=false;
				do {
						System.out.println("enter the account number yow want to transfer");
						try{
							String account=sc.next();
							asc.validateAccNum(Integer.valueOf(account));
							accFlag2=true;
							boolean accFlag3=false;
							do {
								System.out.println("enter the IFSC code");
							try{
								String ifsc=sc.next();
								asc.validateIfsc(ifsc);
								System.out.println("enter amount you want transfer");
								int transfer=sc.nextInt();
								int ac=asc.transferdetails(accnum2, transfer);
								if(ac!=0) {
									System.out.println(+transfer+" successfully transferedc to "+account+" ");
									System.out.println("you successfully transfered amount is: "+ac);
								accFlag3=true;
								break;
								}
								else
									System.out.println("insufficient funds");
								}catch(AccountException e){
									accFlag3=false;
									System.err.println(e.getMessage());
								}
							}while(!accFlag3);
						}catch(AccountException e) {
							accFlag2=false;
							System.err.println(e.getMessage());
						}
				}while(!accFlag2);
			break;
		}else
			System.out.println("enter validate account number");
			}else
				System.out.println("first uou need to create wallet account");
			break;
		case 7:
			if(a.getAccnum()!=0) {
			boolean accFlag6=false;
			int accnum3 = 0;
			do {
			System.out.println("ENTER THE ACCOUNT NUMBER");
			try {
				accnum3=sc.nextInt();
				asc.validateAccNum(accnum3);
				accFlag6=true;
				break;
			}catch(AccountException e)
			{
				accFlag6=false;
				System.err.println(e.getMessage());
			}
			}while(!accFlag6);
			if(accnum3==a.getAccnum()) {
				PrintTransaction pt1=asc.printtransaction(accnum3);
				if(pt1==null)
					System.out.println("first enter the credentials");
				else {
					System.out.println(pt1);
					break;
				}
			}
			else
				System.out.println("invalid account number");
			}else
				System.out.println("first uou need to create wallet account");
		}
				
			}catch(InputMismatchException e)
			{
				choiceFlag = false;
				System.err.println("enter only digits");	
			}
		}while(!choiceFlag);
		
		System.out.println("do u want to continue again(yes/no)");
		continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
	}
		}
	






