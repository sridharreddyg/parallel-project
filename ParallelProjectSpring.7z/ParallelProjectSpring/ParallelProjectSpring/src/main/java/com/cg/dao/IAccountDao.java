package com.cg.dao;

import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.cg.entity.Account;

@Repository
public interface IAccountDao extends CrudRepository<Account,Integer>{

}
