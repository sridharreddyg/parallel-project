package com.cg.service;

import com.cg.Exception.AccountException;
import com.cg.entity.Account;

public interface IAccountService {
	public void display(Account a) ; 
	public Account walDetails(int a,int walbalance);
	public int details(int a,int deposit);
	public int withdrawdetails(int a,int withdraw);
	public int transferdetails(int a,int transfer) ;
	public Account printtransaction(int a);
	void validateMobile(String str)throws AccountException ;
	void validateAdhaar(String str)throws AccountException;
	void validateName(String name)throws AccountException;
	void validateAccNum(int accnum)throws AccountException;
}
