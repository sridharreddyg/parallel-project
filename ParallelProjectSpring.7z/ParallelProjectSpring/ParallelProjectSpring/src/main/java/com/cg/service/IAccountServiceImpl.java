package com.cg.service;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Exception.AccountException;
import com.cg.dao.IAccountDao;
import com.cg.entity.Account;
@Service
public class IAccountServiceImpl implements IAccountService{
@Autowired
IAccountDao accdao;
	@Override
	public void display(Account a) {
		accdao.save(a);
	}

	@Override
	public Account walDetails(int a, int walbalance) {
		return null;
		
	}

	@Override
	public int details(int a, int deposit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int withdrawdetails(int a, int withdraw) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int transferdetails(int a, int transfer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Account printtransaction(int a) {
		// TODO Auto-generated method stub
		return null;
	}

	public void validateMobile(String str) throws AccountException {
		String regx="[6/7/8/9]{1}[0-9]{9}";
		if (Pattern.matches(regx, str) == false) {
			throw new AccountException("enter only 10 digits and starting with 9/8/7/6");
		}	
	}
	public void validateAdhaar(String str) throws AccountException {
		String regx="[0-9]{16}";
		if (Pattern.matches(regx, str) == false) {
			throw new AccountException("Adhaaar should contain 16 digits");
		}
	}
	public void validateName(String name) throws AccountException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, name) == false) {
			throw new AccountException("name should contain only alphabets");
		}	
	}
	public void validateAccNum(int accnum) throws AccountException {
		String regx="[9]{1}[0-9]{8}";
		if (Pattern.matches(regx, String.valueOf(accnum)) == false) {
			throw new AccountException("Account number should contain only 9 digits and starting with 9");
		}
	}
	public void validateIfsc(String str) throws AccountException{
		String regx="[A-Z]{4}[0-9]{7}";
		if(Pattern.matches(regx, str)==false) {
			throw new AccountException("IFSC should be 11 digits and Capital letters and numbers");
		}
	}
	}

