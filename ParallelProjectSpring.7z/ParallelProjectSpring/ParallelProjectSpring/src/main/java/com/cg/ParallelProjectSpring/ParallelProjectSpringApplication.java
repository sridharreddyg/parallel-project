package com.cg.ParallelProjectSpring;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.cg.Exception.AccountException;
import com.cg.entity.Account;
import com.cg.service.IAccountService;
import com.cg.service.IAccountServiceImpl;


@SpringBootApplication
public class ParallelProjectSpringApplication extends SpringBootServletInitializer implements CommandLineRunner{
	@Autowired
	IAccountServiceImpl accserv;
	public SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(ParallelProjectSpringApplication.class);
	}
	public static void main(String[] args) {
		SpringApplication.run(ParallelProjectSpringApplication.class, args);
	}
	@Override
	
	public void run(String... args) {
		Scanner sc;
		Account a=new Account();
		String continueChoice ;
		do {
			
			System.out.println("1:BankAccount number\t 2:create wallet account\t 3:show balance\n"
					+ " 4:Deposit\t 5:withdraw\t6:Transfer\t7:Print Transaction");
			int choice;
			boolean choiceFlag = false;
			do {
				sc=new Scanner(System.in);
				System.out.println("enter your choice");
				try {
					 choice=sc.nextInt();
					choiceFlag = true;
			switch(choice) {
			case 1:
			break;
			case 2:
				int acc;
				String name;
				boolean accFlag = false;
				int max=915009999;
				int min=915000000;
				int range=max-min+1;
				int accnumber=(int) (Math.random()*range)+min;
				System.out.println("yout bank account number is: "+accnumber);
			System.out.println("-------creating wallet waccount---------");
			do {
				sc=new Scanner(System.in);
				System.out.println("enter the account number");
				acc=sc.nextInt();
				try {
					accserv.validateAccNum(acc);
					a.setAccnum(acc);
						accFlag=true;
						break;
					}catch(AccountException e) {
						accFlag = false;
						System.err.println(e.getMessage());
					}
				} while (!accFlag);
							if(acc==a.getAccnum()) {
								boolean nameFlag=false;						
								do { 
									sc = new Scanner(System.in);
									System.out.println("Enter name ");
									name = sc.nextLine();
									try {
										accserv.validateName(name);
										nameFlag = true;
										a.setAccname(name);
										break;

									} catch (AccountException e) {
										nameFlag = false;
										System.err.println(e.getMessage());
									}
								} while (!nameFlag);
						
								boolean mobFlag=false;
								String num;
								do {
								System.out.println("enter the mobile number: ");
								num=sc.next();
								try {
									accserv.validateMobile(num);
									mobFlag=true;
									a.setMobilenumber(Long.valueOf(num));
									break;
								} catch (AccountException e) {
									nameFlag = false;
									System.err.println(e.getMessage());
								}
								}while (!nameFlag);
								boolean adhFlag=false;
								String adh;
								do {
									System.out.println("enter the adhaar number: ");
									 adh=sc.next();
									try {
										accserv.validateAdhaar(adh);
										adhFlag=true;
										a.setAdharnumber(Long.valueOf(adh));
										accserv.display(a);
										System.out.println("yout xyz wallet account is successfully created");
										break;
									}catch (AccountException e) {
										nameFlag = false;
										System.err.println(e.getMessage());
									}
									}while (!adhFlag);
								
							}
							else {					
								System.out.println("account number is invalid");
							}
				break;
			case 3:					
					Account c = null;
					boolean accFlag4=false;
					int accnum;
					do {
					System.out.println("ENTER THE ACCOUNT NUMBER");
					try {
						accnum=sc.nextInt();
						accserv.validateAccNum(accnum);
						accFlag4=true;
					c = accserv.walDetails(accnum, a.getWalbalance());
					System.out.println(c);
					break;
				} catch (AccountException e) {
					accFlag4=false;
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(c);
				}while(!accFlag4);
				break;
			case 4:	
				 boolean accFlag7 = false;
				int ac;
				do {
				System.out.println("ENTER THE ACCOUNT NUMBER");
				try {
					ac=sc.nextInt();
					accserv.validateAccNum(ac);
					accFlag7=true;
					if(a.getAccnum()==ac)
					{
					System.out.println("enter the amount you want deposit");
					int deposit=sc.nextInt();
					int s=accserv.details(ac, deposit);
					System.out.println("successfully deposited: "+deposit);
					System.out.println("your total deposited balance is: "+s);
					break;
					}else
						System.out.println("invalid account number");
				}catch(AccountException e)
				{
					accFlag7=false;
					System.err.println(e.getMessage());
				}
				}while(!accFlag7);
				break;
			case 5:
				boolean accFlag5=false;
				int accnum1;
				do {
				System.out.println("ENTER THE ACCOUNT NUMBER");
				try {
					accnum1=sc.nextInt();
					accserv.validateAccNum(accnum1);
					accFlag5=true;
					if(a.getAccnum()==accnum1) {
						System.out.println("enter amount you want withdraw");
						int withdraw=sc.nextInt();
						int b= accserv.withdrawdetails(accnum1, withdraw);
						if(b!=0) {
							System.out.println("successfully withdrawn: "+withdraw);
							System.out.println("your totally withdrawn balance is: "+b);
							break;
						}
						else
							System.out.println("insufficient funds");
					}else
						System.out.println("invalid account number");
				}catch(AccountException e)
				{
					accFlag5=false;
					System.err.println(e.getMessage());
				}
				}while(!accFlag5);
				break;
			case 6:
				boolean accFlag1=false;
				int accnum2 = 0;
				do {
				System.out.println("ENTER THE ACCOUNT NUMBER");
				try {
					accnum2=sc.nextInt();
					accserv.validateAccNum(accnum2);
					accFlag1=true;
					break;
				}catch(AccountException e)
				{
					accFlag1=false;
					System.err.println(e.getMessage());
				}
				}while(!accFlag1);
				if(a.getAccnum()==accnum2)					
				{
					boolean accFlag2=false;
					do {
							System.out.println("enter the account number yow want to transfer");
							try{
								String account=sc.next();
								accserv.validateAccNum(Integer.valueOf(account));
								accFlag2=true;
								boolean accFlag3=false;
								do {
									System.out.println("enter the IFSC code");
								try{
									String ifsc=sc.next();
									accserv.validateIfsc(ifsc);
									System.out.println("enter amount you want transfer");
									int transfer=sc.nextInt();
									int ac1=accserv.transferdetails(accnum2, transfer);
									if(ac1!=0) {
										System.out.println(+transfer+" successfully transferedc to "+account+" ");
										System.out.println("you successfully transfered amount is: "+ac1);
									accFlag3=true;
									break;
									}
									else
										System.out.println("insufficient funds");
									}catch(AccountException e){
										accFlag3=false;
										System.err.println(e.getMessage());
									}
								}while(!accFlag3);
							}catch(AccountException e) {
								accFlag2=false;
								System.err.println(e.getMessage());
							}
					}while(!accFlag2);
				break;
			}else
				System.out.println("enter validate account number");
				break;
			/*case 7:
				boolean accFlag6=false;
				int accnum3 = 0;
				do {
				System.out.println("ENTER THE ACCOUNT NUMBER");
				try {
					accnum3=sc.nextInt();
					accserv.validateAccNum(accnum3);
					pt.setAccnum(accnum3);
					accFlag6=true;
					break;
				}catch(AccountException e)
				{
					accFlag6=false;
					System.err.println(e.getMessage());
				}
				}while(!accFlag6);
				if(accnum3==a.getAccnum()) {
					PrintTransaction pt1=asc.printtransaction(accnum3);
					if(pt1==null)
						System.out.println("first enter the credentials");
					else {
						System.out.println(pt1);
						break;
					}
				}
				else
					System.out.println("invalid account number");*/
			}
					
				}catch(InputMismatchException e)
				{
					choiceFlag = false;
					System.err.println("enter only digits");	
				}
			}while(!choiceFlag);
			
			System.out.println("do u want to continue again(yes/no)");
			continueChoice = sc.next();
			}while(continueChoice.equalsIgnoreCase("yes"));
		}
			
	}

