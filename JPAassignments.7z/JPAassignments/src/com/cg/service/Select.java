package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpastart.entities.Greet;

public class Select {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();
		Greet greet=new Greet();
		Greet g=entityManager.find(Greet.class, 1);
		System.out.println(g.getFirstName());
		System.out.println(g.getMiddleName());
		System.out.println(g.getLastName());
		System.out.println(g.getPhoneNo());
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();

	}

}
