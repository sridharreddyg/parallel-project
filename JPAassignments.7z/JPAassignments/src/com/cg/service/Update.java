package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Update {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction updateTransaction = entityManager
				.getTransaction();
				updateTransaction.begin();
		
		Query query = entityManager
				.createQuery("UPDATE Greet greet SET greet.firstName = 'sss' "
				+ "WHERE greet.authorId= :id");
		query.setParameter("id", 1);

	    query.executeUpdate();
		updateTransaction.commit();
		entityManager.close();
		emf.close();

	}

}
