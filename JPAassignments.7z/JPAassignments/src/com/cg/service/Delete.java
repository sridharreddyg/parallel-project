package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Delete {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("Delete from Greet WHERE authorId=2 ");
	    query.executeUpdate();
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();

	}

}

