package com.cg.eis.dao;
import java.util.Map;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
import com.cg.eis.util.CollectionUtil;

public class AccDaoClass implements AccDaoInterface{
	CollectionUtil cu=new CollectionUtil();
	Account a=new Account();
	PrintTransaction pt=new PrintTransaction();
	public Map<Integer, Account> display(Account a) {
		return cu.display(a);		
	}
	public Account walDetails(Account a,int walbalance) {
		if(walbalance==0) {
			a.setWalbalance(walbalance);
			return cu.walDetails(a, walbalance);
		}
		else {	
		return cu.walDetails(a, walbalance);
		}
	}
	public Account details(Account a,int deposit) {	
		int walbalance=deposit+a.getWalbalance();
		a.setWalbalance(walbalance);
		a.setDeposite(deposit);
		//pt.setDeposite(deposit);
		return cu.details(a,deposit);
	}
	public Account withdrawdetails(Account a, int withdraw) {
		if(a.getWalbalance()>withdraw) {
			int walbalance=a.getWalbalance()-withdraw;
			withdraw=a.getWithdraw()+withdraw;
			a.setWalbalance(walbalance);
			a.setWithdraw(withdraw);
		}else
			return null;
		return cu.withdrawdetails(a, a.getWithdraw());
		}
		
	public Account transferdetails(Account a, int transfer) {
		if(a.getWalbalance()>transfer) 
		{
			int walbalance=a.getWalbalance()-transfer;
			a.setWalbalance(walbalance);
			a.setTransfer(transfer);
		return cu.transferdetails(a, a.getTransfer());
	}else
		return null;
	}
	public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt) {
		return cu.printtransaction(a,pt);
	}
}