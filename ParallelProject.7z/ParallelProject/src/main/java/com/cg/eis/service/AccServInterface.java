package com.cg.eis.service;

import java.util.Map;
import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
public interface AccServInterface {
	public Map<Integer, Account> display(Account a); 
	public Account walDetails(Account a,int walbalance);
	public Account details(Account a,int deposit);
	public Account withdrawdetails(Account a,int withdraw);
	public Account transferdetails(Account a,int transfer);
	public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt);
	void validateMobile(String str) throws AccountException;
	void validateAdhaar(String str)throws AccountException;
	void validateName(String name)throws AccountException;
	void validateAccNum(int accnum)throws AccountException;
	
}
