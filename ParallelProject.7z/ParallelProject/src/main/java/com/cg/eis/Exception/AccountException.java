package com.cg.eis.Exception;

public class AccountException extends Exception{

	public AccountException(String arg0) {
		super(arg0);

	}

}
