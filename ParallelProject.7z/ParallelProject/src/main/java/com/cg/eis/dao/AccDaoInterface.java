package com.cg.eis.dao;

import java.util.Map;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
public interface AccDaoInterface { 
	public Map<Integer, Account> display(Account a);
	public Account walDetails(Account a,int walbalance);
	public Account details(Account a,int deposit); 
	public Account withdrawdetails(Account a,int withdraw);
	public Account transferdetails(Account a,int transfer);
	public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt);
}
