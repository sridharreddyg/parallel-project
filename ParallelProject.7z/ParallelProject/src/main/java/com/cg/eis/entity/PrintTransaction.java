package com.cg.eis.entity;

public class PrintTransaction {
	public int getDeposite() {
		return deposite;
	}
	public void setDeposite(int deposite) {
		this.deposite = deposite;
	}
	public int getTransfer() {
		return transfer;
	}
	public void setTransfer(int transfer) {
		this.transfer = transfer;
	}
	@Override
	public String toString() {
		return "PrintTransaction [withdraw=" + withdraw + ", deposite=" + deposite + ", transfer=" + transfer +
				 "]";
	}
	private int withdraw;
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	private int deposite;
	private int transfer;

}
