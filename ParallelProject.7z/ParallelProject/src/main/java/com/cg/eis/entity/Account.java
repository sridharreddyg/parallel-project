package com.cg.eis.entity;

public class Account {
	private long mobilenum;
	public long getMobilenum() {
		return mobilenum;
	}
	public void setMobilenum(long num) {
		this.mobilenum = num;
	}
	public Account(long mobilenum, int walbalance, int accnum, long adhaarnum, String accname, int deposite,
			int transfer, int withdraw, int walpin) {
		super();
		this.mobilenum = mobilenum;
		this.walbalance = walbalance;
		this.accnum = accnum;
		this.adhaarnum = adhaarnum;
		this.accname = accname;
		this.deposite = deposite;
		this.transfer = transfer;
		this.withdraw = withdraw;
		this.walpin = walpin;
	}
	public int getWalbalance() {
		return walbalance;
	}
	public int setWalbalance(int walbalance) {
		return this.walbalance = walbalance;
	}
	public long getAdhaarnum() {
		return adhaarnum;
	}
	public void setAdhaarnum(long adh) {
		this.adhaarnum = adh;
	}
	@Override
	public String toString() {
		return "Account [mobilenum=" + mobilenum + ", walbalance=" + walbalance + ", accnum=" + accnum + ", adhaarnum="
				+ adhaarnum + ", accname=" + accname + ", deposite=" + deposite + ", transfer=" + transfer
				+ ", withdraw=" + withdraw + "]";
	}
	public int getAccnum() {
		return accnum;
	}
	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}
	public String getAccname() {
		return accname;
	}
	public void setAccname(String accname) {
		this.accname = accname;
	}
	public Account() {
		super();
	}
	private int walbalance,accnum;
private long  adhaarnum;	
private String accname;
private int deposite;
private int transfer;
private int withdraw,walpin;
public int getWalpin() {
	return walpin;
}
public void setWalpin(int walpin) {
	this.walpin = walpin;
}
public int getDeposite() {
	return deposite;
}
public void setDeposite(int deposite) {
	this.deposite = deposite;
}
public int getTransfer() {
	return transfer;
}
public void setTransfer(int transfer) {
	this.transfer = transfer;
}
public int getWithdraw() {
	return withdraw;
}
public void setWithdraw(int withdraw) {
	this.withdraw = withdraw;
}
}
