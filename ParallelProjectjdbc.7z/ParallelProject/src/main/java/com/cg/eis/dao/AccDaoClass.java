package com.cg.eis.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
import com.cg.eis.util.CollectionUtil;

public class AccDaoClass implements AccDaoInterface{
	static Connection c;
	Statement stmt=null;
	ResultSet rs=null;
	PreparedStatement preparedStmt=null;
	public AccDaoClass(){
	try {
		Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
			System.out.println("connected");
			String query="insert into BankAccount (accnum, accname, mobnum, adhnum, deposit,withdraw,transfer,walbalance)"+"values(?,?,?,?,?,?,?,?)";
		 preparedStmt = c.prepareStatement(query);
			stmt.close();
			c.close();
	}catch(Exception e) {
		System.out.println(e);
	}
	}
	CollectionUtil cu=new CollectionUtil();
	Account a=new Account();
	PrintTransaction pt=new PrintTransaction();
	public void display(Account a) throws AccountException {
		try {
			PreparedStatement preparedStmt=AccDaoClass.c.prepareStatement("insert into BankAccount values(?,?,?,?)");
		preparedStmt.setInt(1, a.getAccnum());
		preparedStmt.setString(2, a.getAccname());
		preparedStmt.setLong(3, a.getMobilenum());
		preparedStmt.setLong(4, a.getAdhaarnum());
		preparedStmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	public ResultSet walDetails(Account a,int walbalance) throws AccountException {
		if(walbalance==0) {
			try {
				 preparedStmt = AccDaoClass.c.prepareStatement("insert into BankAccount values(?)");
				 preparedStmt.executeQuery();
				preparedStmt.setInt(8, walbalance);
				if(rs.getLong(1)==a.getAccnum())
					return rs;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return rs;
	}
	public int details(Account a,int deposit) throws SQLException {	
		 preparedStmt = AccDaoClass.c.prepareStatement("update BankAccount set walbalance=walbalance+? where accnum=?");
		 preparedStmt.setLong(2, a.getAccnum());
		 preparedStmt.setInt(1, deposit);
		rs= preparedStmt.executeQuery();
	while(rs.next()) {
		return rs.getInt(1);
	}
	return rs.getInt(1);
	}
	public int withdrawdetails(Account a, int withdraw) throws SQLException {
		 preparedStmt = AccDaoClass.c.prepareStatement("update BankAccount set walbalance=walbalance-? where accnum=?");		
		 preparedStmt.setInt(1, withdraw);
		 preparedStmt.setLong(2, a.getAccnum());
		 rs= preparedStmt.executeQuery();
		 
		 while(rs.next())
				return rs.getInt(1);	
		return rs.getInt(1);
	}
		
	public int transferdetails(Account a, int transfer) throws SQLException {
		 preparedStmt = AccDaoClass.c.prepareStatement("update BankAccount set walbalance=walbalance-? where accnum=?");
		 preparedStmt.setInt(1, transfer);
		 preparedStmt.setLong(2, a.getAccnum());
		 rs= preparedStmt.executeQuery();
		 while(rs.next())
			 return rs.getInt(1);
		return rs.getInt(1);
		
	}
	public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt) {
		return cu.printtransaction(a,pt);
	}
	
}