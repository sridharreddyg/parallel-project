package com.cg.eis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
public interface AccDaoInterface { 
	public void display(Account a) throws AccountException;
	public ResultSet walDetails(Account a,int walbalance) throws AccountException;
	public int details(Account a,int deposit) throws SQLException; 
	public int withdrawdetails(Account a,int withdraw) throws SQLException;
	public int transferdetails(Account a,int transfer) throws AccountException, SQLException;
	public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt);
}
