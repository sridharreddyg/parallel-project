package com.cg.eis.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
public interface AccServInterface {
	public void display(Account a) throws AccountException; 
	public ResultSet walDetails(Account a,int walbalance)throws AccountException;
	public int details(Account a,int deposit) throws SQLException;
	public int withdrawdetails(Account a,int withdraw)throws SQLException;
	public int transferdetails(Account a,int transfer) throws SQLException;
	public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt);
	void validateMobile(String str) throws AccountException;
	void validateAdhaar(String str)throws AccountException;
	void validateName(String name)throws AccountException;
	void validateAccNum(int accnum)throws AccountException;

}
