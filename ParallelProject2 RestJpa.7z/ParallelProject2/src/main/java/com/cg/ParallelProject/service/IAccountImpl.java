package com.cg.ParallelProject.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cg.ParallelProject.dao.AccountRepository;
import com.cg.ParallelProject.enity.Account;

@Service
public class IAccountImpl implements IAccount{
	@Autowired
AccountRepository accrepo;
	@Autowired
	Account account;
	@Override
	public Account createAccount(Account account) {
		int min=100000000;
		int max=999999999;
		int range=(max-min)+1;
		int accnum=(int)(Math.random()*range)+min;
		account.setAccnum(accnum);
		return accrepo.save(account);
	}

	@Override
	public int showbalance(int accnum) {
		
		return accrepo.findById(accnum).get().getWalbalance();
	}

	@Override
	public int deposit(int accnum, int deposit) {
		account=accrepo.findById(accnum).get();
		int walbalance=account.getWalbalance()+deposit;
		account.setWalbalance(walbalance);
		account.setDeposit(deposit);
		accrepo.save(account);
		return account.getDeposit();
	}

	@Override
	public int withdraw(int accnum, int withdraw) {
		account=accrepo.findById(accnum).get();
		if(account.getWalbalance()<withdraw) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance = account.getWalbalance()-withdraw;
		 account.setWalbalance(balance);
		 account.setWithdraw(withdraw);
		 accrepo.save(account);
		 return account.getWithdraw();
		}
			
	}

	@Override
	public int transfer(int accnum, int transfer) {
		account=accrepo.findById(accnum).get();
		if(account.getWalbalance()<transfer) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance = account.getWalbalance()-transfer;
		 account.setWalbalance(balance);
		 account.setTransfer(transfer);
		 accrepo.save(account);
		 return account.getTransfer();
		}
	}

	@Override
	public String validateAccnum(int accnum) {
		String str;
		account=accrepo.findById(accnum).get();
				if(account!=null) {
					str="account number exists";
			return str;
				}
				else {
					str="account number not exists";
		return str;
				}
	}

}
