package com.cg.eis.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
public interface AccDaoInterface { 
	public void display(Account a) throws AccountException;
	public Account walDetails(int a,int walbalance) throws AccountException;
	public int details(int a,int deposit) throws AccountException; 
	public int withdrawdetails(int a,int withdraw) throws AccountException;
	public int transferdetails(int a,int transfer) throws AccountException, SQLException;
	public PrintTransaction printtransaction(int a) throws AccountException;
}
