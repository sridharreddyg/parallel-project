package com.cg.eis.service;


import java.sql.SQLException;
import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;
public interface AccServInterface {
	public void display(Account a) throws AccountException; 
	public Account walDetails(int a,int walbalance)throws AccountException;
	public int details(int a,int deposit) throws AccountException;
	public int withdrawdetails(int a,int withdraw)throws AccountException;
	public int transferdetails(int a,int transfer) throws AccountException;
public PrintTransaction printtransaction(int a) throws AccountException;
	void validateMobile(String str) throws AccountException;
	void validateAdhaar(String str)throws AccountException;
	void validateName(String name)throws AccountException;
	void validateAccNum(int accnum)throws AccountException;

}
