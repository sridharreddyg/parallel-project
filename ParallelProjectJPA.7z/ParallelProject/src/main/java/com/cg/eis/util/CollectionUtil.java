package com.cg.eis.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;

public class CollectionUtil {
	public Connection c=null;
	{
	try {
	Class.forName("oracle.jdbc.OracleDriver");
	c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
	}catch(ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

/*static Map<Integer,Account> hm=new HashMap<Integer, Account>();
Map<Integer,PrintTransaction>hp=new HashMap<Integer,PrintTransaction>();
public  Map<Integer, Account> display(Account a) {
	hm.put(a.getAccnum(), a);
	return hm;	
}
public Account walDetails(Account a,int walbalance) {
	hm.put(a.getWalbalance(), a);
	return hm.get(walbalance);
}
public Account details(Account a,int deposit) {
	hm.put(a.getDeposite(), a);
	Account ac=hm.get(deposit);
	return ac;	
}
public Account withdrawdetails(Account a,int withdraw) {
	hm.put(a.getWithdraw(), a);
	Account ac=hm.get(withdraw);
	return ac;
	
}
public Account transferdetails(Account a,int transfer) {
	hm.put(a.getTransfer(), a);
	Account ac=hm.get(transfer);
	return ac;	
}
public Map<Integer, PrintTransaction> printtransaction(Account a,PrintTransaction pt) {
	hp.put(a.getAccnum(), pt);
	return hp;
}*/
}
}


