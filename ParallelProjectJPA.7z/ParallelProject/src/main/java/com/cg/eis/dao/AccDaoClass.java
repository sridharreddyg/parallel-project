package com.cg.eis.dao;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.eis.Exception.AccountException;
import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;

public class AccDaoClass implements AccDaoInterface{
	 EntityManagerFactory emf=Persistence.createEntityManagerFactory("ParallelProject");
	 EntityManager em=emf.createEntityManager();

@Override
public void display(Account a) throws AccountException {
	em.getTransaction().begin();
	em.persist(a);
	em.getTransaction().commit();
	emf.close();
	
}
@Override
public Account walDetails(int a, int walbalance) throws AccountException {
	em.getTransaction().begin();
	String str="Select acc From Account acc where acc.accnum=:accnum";
	TypedQuery<Account> query=em.createQuery(str,Account.class); 
	query.setParameter("accnum", a);
	Account acc=query.getSingleResult();
	em.getTransaction().commit();
	emf.close();
	return acc;
}
@Override
public int details(int a, int deposit) throws AccountException {
	em.getTransaction().begin();
	Account ac=em.find(Account.class,a);
	PrintTransaction pt=em.find(PrintTransaction.class, a);
	int deposit1=deposit+ac.getDeposite();
	int walbalance=ac.getWalbalance()+deposit;
	ac.setDeposite(deposit1);
	ac.setWalbalance(walbalance);
	pt.setDeposite(deposit1);
	em.persist(ac);
	em.persist(pt);
	em.getTransaction().commit();
	emf.close();
	return ac.getWalbalance();
}
@Override
public int withdrawdetails(int a, int withdraw) throws AccountException {
	em.getTransaction().begin();
	Account ac=em.find(Account.class,a);
	PrintTransaction pt=em.find(PrintTransaction.class, a);
	if(ac.getWalbalance()>withdraw) {
	int withdraw1=withdraw+ac.getWithdraw();
	int walbalance=ac.getWalbalance()-withdraw;
	ac.setWithdraw(withdraw1);
	ac.setWalbalance(walbalance);
	pt.setWithdraw(withdraw1);
	em.persist(ac);
	em.persist(pt);
	}else
		System.out.println("insufficient funds");
	return ac.getWalbalance();
}
@Override
public int transferdetails(int a, int transfer) throws AccountException {
	em.getTransaction().begin();
	int walbalance = 0;
	Account ac=em.find(Account.class, a);
	PrintTransaction pt=em.find(PrintTransaction.class, a);
	if(ac.getWalbalance()>transfer) {
	int transfer1=transfer+ac.getTransfer();
	walbalance=ac.getWalbalance()-transfer;
	ac.setWalbalance(walbalance);
	ac.setTransfer(transfer1);
	pt.setTransfer(transfer1);
	em.persist(ac);
	em.persist(pt);
	}
	else
		System.out.println("insufficient funds");
	em.getTransaction().commit();
	return ac.getWalbalance();
}
@Override
public PrintTransaction printtransaction(int a) throws AccountException {
	em.getTransaction().begin();
	String str="select pt from PrintTransaction pt where pt.accnum=:accnum";
	TypedQuery<PrintTransaction> query=em.createQuery(str,PrintTransaction.class); 
	query.setParameter("accnum", a);
	PrintTransaction pt=query.getSingleResult();
	em.getTransaction().commit();
	return pt;
}
}
