package com.cg.eis.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class PrintTransaction {
	@Id
	private int Accnum;
	public PrintTransaction(int accnum, int withdraw, int deposite, int transfer) {
		super();
		Accnum = accnum;
		this.withdraw = withdraw;
		this.deposite = deposite;
		this.transfer = transfer;
	}
	public int getAccnum() {
		return Accnum;
	}
	public void setAccnum(int accnum) {
		Accnum = accnum;
	}
	public PrintTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getDeposite() {
		return deposite;
	}
	public void setDeposite(int deposite) {
		this.deposite = deposite;
	}
	public int getTransfer() {
		return transfer;
	}
	public void setTransfer(int transfer) {
		this.transfer = transfer;
	}
	@Override
	public String toString() {
		return "Transaction details is {"
				+ " Total withdrawn amount=" + withdraw +
				",Total deposited amount=" + deposite + 
				",Total transfered amount=" + transfer +
				 "}";
	}
	private int withdraw;
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	private int deposite;
	private int transfer;

}
