package com.cg.eis.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import java.util.regex.Pattern;

import com.cg.eis.entity.Account;
import com.cg.eis.entity.PrintTransaction;

import com.cg.eis.Exception.AccountException;
import com.cg.eis.dao.AccDaoClass;

public class AccServClass implements AccServInterface {
static AccDaoClass adc=new AccDaoClass();
public void display(Account a) throws AccountException {
 adc.display(a);	
}
public Account walDetails(int a,int walbalance) throws AccountException {
	return adc.walDetails(a,walbalance);
}
public int details(int a,int deposit) throws AccountException {
	return adc.details(a,deposit);
	
}
public int withdrawdetails(int a, int withdraw) throws AccountException {
	return adc.withdrawdetails(a, withdraw);
}
public int transferdetails(int a, int transfer) throws AccountException {
	// TODO Auto-generated method stub
	return adc.transferdetails(a, transfer);
}
public PrintTransaction printtransaction(int a) throws AccountException {
	return adc.printtransaction(a);
}
public void validateMobile(String str) throws AccountException {
	String regx="[6/7/8/9]{1}[0-9]{9}";
	if (Pattern.matches(regx, str) == false) {
		throw new AccountException("enter only 10 digits and starting with 9/8/7/6");
	}	
}
public void validateAdhaar(String str) throws AccountException {
	String regx="[0-9]{16}";
	if (Pattern.matches(regx, str) == false) {
		throw new AccountException("Adhaaar should contain 16 digits");
	}
}
public void validateName(String name) throws AccountException {
	String nameRegEx = "[a-zA-Z ]+";
	if (Pattern.matches(nameRegEx, name) == false) {
		throw new AccountException("name should contain only alphabets");
	}	
}
public void validateAccNum(int accnum) throws AccountException {
	String regx="[9]{1}[0-9]{8}";
	if (Pattern.matches(regx, String.valueOf(accnum)) == false) {
		throw new AccountException("Account number should contain only 9 digits and starting with 9");
	}
}
public void validateIfsc(String str) throws AccountException{
	String regx="[A-Z]{4}[0-9]{7}";
	if(Pattern.matches(regx, str)==false) {
		throw new AccountException("IFSC should be 11 digits and Capital letters and numbers");
	}
}
}
	