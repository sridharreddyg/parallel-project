package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entity.Account;
import com.cg.service.IAccount;

public class AccountController {
@Autowired
IAccount accountservice;
@RequestMapping("/index")
public String showForm(Model model) {		
	model.addAttribute("user",new Account());
	return "index";		
}
	/*
	 * @RequestMapping("/add") public String add(Model model) { Account account=new
	 * Account();
	 * 
	 * model.addAttribute("account", account);
	 * 
	 * return "add"; }
	 */

@RequestMapping(value="/createaccount", method=RequestMethod.GET)
public String addTrainee(@ModelAttribute("account") Account account,Model model) {
	model.addAttribute("account", accountservice.createAccount(account));
	return "create";
}

	/*
	 * @RequestMapping("/find") public String find(Model model) {
	 * model.addAttribute("account",new Account()); return "find"; }
	 */

@RequestMapping(value="/showbalance", method=RequestMethod.GET)
public String findTrainee(@ModelAttribute("account") Account account,Model model) {
	model.addAttribute("account", accountservice.showBalance(account.getAccnum()));
	return "showBalance";
}

	/*
	 * @RequestMapping("/deposit") public String deposit(Model model) {
	 * model.addAttribute("account",new Account()); return "deposit"; }
	 */

@RequestMapping("/deposits")
public String deposited(@ModelAttribute("account") Account account,Model model) {

	model.addAttribute("account",accountservice.deposit(account.getWalbalance(), account.getAccnum()));
	return "deposit";
}

	/*
	 * @RequestMapping("/withdraw") public String withdraw(Model model) {
	 * model.addAttribute("account",new Account()); return "withdraw"; }
	 */

@RequestMapping("/withdraws")
public String withdrawn(@ModelAttribute("account") Account account,Model model) {

	model.addAttribute("account",accountservice.withdraw(account.getWalbalance(), account.getAccnum()));
	return "withdraw";
}

	/*
	 * @RequestMapping("/printTransactions") public String ptrans(Model model) {
	 * model.addAttribute("account",new Account()); return "printtransaction"; }
	 */
@RequestMapping("/pTransaction")
public String ptran(@ModelAttribute("account") Account account,Model model) {
	model.addAttribute("account",accountservice.printTransaction(account.getAccnum()));
	return "ptransaction";
			
}

	/*
	 * @RequestMapping("/fundtransfer") public String fundtransfer(Model model) {
	 * model.addAttribute("account",new Account()); return "ftransfer"; }
	 * 
	 * @RequestMapping("/fundtransfers") public String
	 * ftrans(@ModelAttribute("account") Account account,Model model) {
	 * accountservice.withdraw(account.getWalbalance(), account.getAccnum());
	 * model.addAttribute("account1",account.getWalbalance()); return "ftransfers";
	 * }
	 */
@RequestMapping("/fundtransfer")
public String ftranss(@ModelAttribute("account") Account account,Model model) {
	 model.addAttribute("account",accountservice.deposit(account.getWalbalance(), account.getAccnum()));
	 return "transfer";
}
}
