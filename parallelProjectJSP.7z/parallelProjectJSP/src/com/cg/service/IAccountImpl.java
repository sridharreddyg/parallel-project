package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IAccountDAO;
import com.cg.entity.Account;
@Service
@Transactional
public class IAccountImpl implements IAccount{
@Autowired
IAccountDAO accountdao;
	@Override
	public int createAccount(Account a) {
		// TODO Auto-generated method stub
		return accountdao.createAccount(a);
	}

	@Override
	public int showBalance(int accountNo) {
		// TODO Auto-generated method stub
		return accountdao.showBalance(accountNo);
	}

	@Override
	public int deposit(int amount, int accountNo) {
		// TODO Auto-generated method stub
		return accountdao.deposit(amount, accountNo);
	}

	@Override
	public int withdraw(int amount, int accountNo) {
		// TODO Auto-generated method stub
		return accountdao.withdraw(amount, accountNo);
	}

	@Override
	public int fundTransfer(int accnum, int transfer) {
		// TODO Auto-generated method stub
		return accountdao.fundTransfer(accnum, transfer);
	}

	@Override
	public Account printTransaction(int accountNo) {
		// TODO Auto-generated method stub
		return accountdao.printTransaction(accountNo);
	}

}
