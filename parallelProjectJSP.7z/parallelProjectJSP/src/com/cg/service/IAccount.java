package com.cg.service;

import com.cg.entity.Account;

public interface IAccount {
	public int createAccount(Account a);
	public int showBalance(int accountNo);
	public int deposit(int amount,int accountNo);
	public int withdraw(int amount,int accountNo);
	public int fundTransfer(int accnum,int transfer);
	public Account printTransaction(int accountNo);
}
