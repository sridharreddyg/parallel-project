package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entity.Account;
@Repository
public class IAccountDAOImpl implements IAccountDAO{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public int createAccount(Account a) {
		int min=100000000;
		int max=999999999;
		int range=(max-min)+1;
		int accnum=(int)(Math.random()*range)+1;
		a.setAccnum(accnum);
		entityManager.persist(a);
		return a.getAccnum();
	}

	@Override
	public int showBalance(int accountNo) {
		Account account=entityManager.find(Account.class,accountNo);
		return account.getWalbalance();
	}

	@Override
	public int deposit(int amount, int accountNo) {
		Account account=entityManager.find(Account.class,accountNo );
		int deposit=account.getWalbalance()+amount;
		account.setDeposit(deposit);
		int deposit1=account.getDeposit()+amount;
		account.setDeposit(deposit1);
		entityManager.merge(account);
		return account.getWalbalance();
	}

	@Override
	public int withdraw(int amount, int accountNo) {
		Account account=entityManager.find(Account.class,accountNo );
		int amount1=account.getWalbalance()-amount;
		account.setWalbalance(amount1);
		int withdraw1=account.getWithdraw()+amount;
		account.setWithdraw(withdraw1);
		entityManager.merge(account);
		return account.getWalbalance();
	}

	@Override
	public int fundTransfer(int accnum, int transfer) {
		Account account=entityManager.find(Account.class,accnum );
		int amount=account.getWalbalance()-transfer;
		account.setWalbalance(amount);
		int transfer1=account.getTransfer()+transfer;
		account.setTransfer(transfer1);
		entityManager.merge(account);
		return account.getWalbalance();
	}

	@Override
	public Account printTransaction(int accountNo) {
		// TODO Auto-generated method stub
		return entityManager.find(Account.class,accountNo);
	}

}
