package com.cg.ParallelProject.enity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Accoundetails")
@Component
public class Account implements Serializable{
	@Id
private int accnum;
@NotNull
@Pattern(regexp="[a-zA-Z]",message="only alphabets")
private String accname;
@NotNull
private long mobilenumber;
@NotNull
private long adharnumber;
@JoinColumn(name="walid")
private Wallet wallet;

public Wallet getWallet() {
	return wallet;
}
public void setWallet(Wallet wallet) {
	this.wallet = wallet;
}
public int getAccnum() {
	return accnum;
}
public Account() {
	super();
	// TODO Auto-generated constructor stub
}
public Account(int accnum, @NotNull @Pattern(regexp = "[a-zA-Z]", message = "only alphabets") String accname,
		@NotNull @Pattern(regexp = "[9/8/7/6]{1}[0-9]{9}", message = "mobile number shold be 10 digits") long mobilenumber,
		@NotNull @Pattern(regexp = "[0-9]{12}", message = "adhar should be 12 digits") long adharnumber) {
	super();
	this.accnum = accnum;
	this.accname = accname;
	this.mobilenumber = mobilenumber;
	this.adharnumber = adharnumber;
}
public void setAccnum(int accnum) {
	this.accnum = accnum;
}
public String getAccname() {
	return accname;
}
public void setAccname(String accname) {
	this.accname = accname;
}
public long getMobilenumber() {
	return mobilenumber;
}
public void setMobilenumber(long mobilenumber) {
	this.mobilenumber = mobilenumber;
}
public long getAdharnumber() {
	return adharnumber;
}
public void setAdharnumber(long adharnumber) {
	this.adharnumber = adharnumber;
}

}