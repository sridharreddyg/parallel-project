package com.cg.ParallelProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ParallelProject.dao.AccountRepository;
import com.cg.ParallelProject.enity.Account;
import com.cg.ParallelProject.enity.Wallet;

@Service
public class IAccountImpl implements IAccount{
	@Autowired
AccountRepository accrepo;
	@Autowired
	Account account;
	@Autowired
	Wallet wallet;
	@Override
	public Account createAccount(Account account) {
		int min=100000000;
		int max=999999999;
		int range=(max-min)+1;
		int accnum=(int)(Math.random()*range)+min;
		account.setAccnum(accnum);
		return accrepo.save(account);
	}

	@Override
	public int showbalance(int accnum) {
		
		return accrepo.findById(accnum).get().getWallet().getWalbalance();
	}

	@Override
	public int deposit(int accnum, int deposit) {
		account=accrepo.findById(accnum).get();
		int walbalance=account.getWallet().getWalbalance()+deposit;
		account.getWallet().setWalbalance(walbalance);
		int depo=account.getWallet().getDeposit()+deposit;
		account.getWallet().setDeposit(depo);
		accrepo.save(account);
		return deposit;
	}

	@Override
	public int withdraw(int accnum, int withdraw) {
		account=accrepo.findById(accnum).get();
		if(account.getWallet().getWalbalance()<withdraw) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance = account.getWallet().getWalbalance()-withdraw;
		 account.getWallet().setWalbalance(balance);
		 int withdrawn=account.getWallet().getDeposit()+withdraw;
		 account.getWallet().setWithdraw(withdrawn);
		 return withdraw;
		}
			
	}

	@Override
	public int transfer(int accnum, int transfer) {
		account=accrepo.findById(accnum).get();
		if(account.getWallet().getWalbalance()<transfer) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance = account.getWallet().getWalbalance()-transfer;
		 account.getWallet().setWalbalance(balance);
		 int withdrawn=account.getWallet().getDeposit()+transfer;
		 account.getWallet().setTransfer(withdrawn);
		 return transfer;
		}
	}

	@Override
	public String validateAccnum(int accnum) {
		String str;
		account=accrepo.findById(accnum).get();
				if(account!=null) {
					str="account number exists";
			return str;
				}
				else {
					str="account number not exists";
		return str;
				}
	}

}
