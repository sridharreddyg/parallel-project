package com.cg.ParallelProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ParallelProject.enity.Wallet;
@Repository
public interface PrintTransactionRepository extends JpaRepository<Wallet, Integer>{

}
