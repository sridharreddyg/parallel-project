package com.cg.ParallelProject.enity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="waldetails")
@Component
public class Wallet implements Serializable {
	@Id
private int walid;
	private int walbalance;
public Wallet(int walid, int walbalance, int deposit, int withdraw, int transfer) {
		super();
		this.walid = walid;
		this.walbalance = walbalance;
		this.deposit = deposit;
		this.withdraw = withdraw;
		this.transfer = transfer;
	}
public int getWalbalance() {
		return walbalance;
	}
	public void setWalbalance(int walbalance) {
		this.walbalance = walbalance;
	}
public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}
public Wallet(int walid, int deposit, int withdraw, int transfer) {
		super();
		this.walid = walid;
		this.deposit = deposit;
		this.withdraw = withdraw;
		this.transfer = transfer;
	}
@Override
public String toString() {
	return "Wallet [walid=" + walid + ", walbalance=" + walbalance + ", deposit=" + deposit + ", withdraw=" + withdraw
			+ ", transfer=" + transfer + "]";
}
public int getWalid() {
		return walid;
	}
	public void setWalid(int walid) {
		this.walid = walid;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	public int getTransfer() {
		return transfer;
	}
	public void setTransfer(int transfer) {
		this.transfer = transfer;
	}
private int deposit;
private int withdraw;
private int transfer;

}
